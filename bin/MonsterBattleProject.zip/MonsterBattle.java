//Alex Santeramo
//This class has a giant and an ogre fight one another if the user chooses to have the default battle, if the user chooses to have a custom battle they can have two files be read in that can create new monsters to fight. 
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class MonsterBattle 
{

	public static void main(String[] args) 
	{
		System.out.println("Would you like to run a default battle, or a custom one? Type: 1 for Default or 2 for Custom.");
		Scanner input = new Scanner(System.in);
		String answer = input.next();
		if(answer.equals("1"))
		{
			//Creates the two monsters to fight.
			Monster Giant = new Monster(200.00, 25.00, "Giant");
			Monster Ogre = new Monster(100.00, 50.00, "Ogre");
			//Plays out the battle.
			do
			{
				double hit = Giant.attack();
				Ogre.takeDamage(hit);
				System.out.println("Giant attacked Ogre for " + hit + " damage.");
				double hit2 = Ogre.attack();
				Giant.takeDamage(hit2);
				System.out.println("Ogre attacked Giant for " + hit2 + " damage. ");
				System.out.println(Giant + " " + Ogre);
			} while (Giant.isAlive() == true && Ogre.isAlive() == true);
			//Determines the outcome of the fight depending on what monster died.
			if(Giant.isAlive() == false)
			{
				System.out.println("Ogre wins!");
			}
			else if(Ogre.isAlive() == false)
			{
				System.out.println("Giant wins!");
			}
			else if(Giant.isAlive() == false && Ogre.isAlive() == false)
			{
				System.out.println("It's a draw!");
			}
		}
		else if (answer.equals("2"))
		{
			//Don't know how to get this working. I would appreciate if I could talk with you on how to fix this part of the program.
			System.out.println("Please enter two filenames to create the monsters with.");
			Scanner input2 = new Scanner(System.in);
			String fileName = input.next();
			readMonster(fileName);
			do
			{
				double hit = customMonsterA.attack();
				customMonsterB.takeDamage(hit);
				System.out.println(customMonsterA.getName() + " attacked " customMonsterB.getName() + " for " + hit + " damage.");
				double hit2 = customMonsterB.attack();
				customMonsterA.takeDamage(hit2);
				System.out.println(customMonsterB.getName() + " attacked " customMonsterA.getName() + " for " + hit + " damage.");				
				System.out.println(customMonsterA + " " + CustomMonsterB);
			} while (customMonsterA.isAlive() == true && customMonsterB.isAlive() == true);
		}

	}
	//Takes a file name and converts its contents into a monster that is returned to the program.
	public static Monster readMonster(String monsterFile1)
	{	
		Scanner input2 = new Scanner(System.in);
		String fileName = input2.next();
		File monsterFileA = new File(fileName);
		Scanner fileInput = null;
		try
		{
			fileInput = new Scanner(monsterFileA);
		}
		catch (FileNotFoundException e)
		{
			System.out.println("Please enter two filenames to create the monsters with.");
			return null;
		}
		String Name = fileInput.nextLine();
		double health = fileInput.nextDouble();
		double strength = fileInput.nextDouble();
		Monster customMonsterA = new Monster(health, strength, Name);
		return customMonsterA;
	}

}
