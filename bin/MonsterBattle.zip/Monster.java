//Alex Santeramo
//Creates a monster from the parameters such as: name, health, and strength
import java.util.Random;

public class Monster 
{
		private double health = 0.0;
		private double strength = 0.0;
		private boolean isAlive = true;
		private String Name;
		
		public Monster()
		{
			health = 0.0;
			strength = 0.0;
		}
		
		public Monster(double health, double strength, String name)
		{
			this.health = health;
			this.strength = strength;
			this.Name = name;
			
		}
		
		public double getHealth()
		{
			return health;
		}
		
		public double getStrength()
		{
			return strength;
		}
		
		public String getName()
		{
			return Name;
		}
		
		public void setHealth(double newHealth)
		{
			health = newHealth;
		}
		
		public void setStrength(double newStrength)
		{
			strength = newStrength;
		}
		
		public void setName(String name)
		{
			Name = name;
		}
		
		public double attack()
		{
			Random random = new Random();
			double randomNumber = random.nextDouble();
			return ((strength * randomNumber));
		}
		
		public void takeDamage(double attack)
		{
			health = health - attack;
		}
		
		public boolean isAlive()
		{
			if(health > 0)
			{
				isAlive = true;
				return isAlive;
			}
			else
			{
				isAlive = false;
				return isAlive;
			}
		}
		
		public String toString()
		{
			String Stats = String.format(Name + "(Health: %.2f, Strength: %.2f)", health, strength);
			return Stats;	
		}
}
